'use strict'
let inputCopy = false;
let memory = false;
let mas = false;


document.querySelector('#add').addEventListener('click', function () {


    mas = document.querySelector('.operation').value;
    document.querySelector('.operation').value = mas + ' + ';



});

document.querySelector('#minus').addEventListener('click', function () {


    let minus = document.querySelector('.operation').value;
    document.querySelector('.operation').value = minus + ' - ';



});
document.querySelector('#multiply').addEventListener('click', function () {


    let multiply = document.querySelector('.operation').value;
    document.querySelector('.operation').value = multiply + ' * ';



});
document.querySelector('#division').addEventListener('click', function () {


    let division = document.querySelector('.operation').value;
    document.querySelector('.operation').value = division + ' / ';



});
document.querySelector('#delete').addEventListener('click', function () {



    document.querySelector('.operation').value = '';



});

document.querySelector('#result').addEventListener('click', function () {


    memory = (document.querySelector('.operation').value);
    inputCopy = eval(memory);

    let paragraph = document.getElementById("operation_result");
    let text = document.createTextNode(inputCopy);

    paragraph.appendChild(text);




    console.log(memory, typeof memory);
    console.log(inputCopy, typeof inputCopy);


});







/*
document.querySelector('.check').addEventListener('click', function () {
    const guess = Number(document.querySelector('.guess').value);
    console.log(guess, typeof guess);
});

*/